
package view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

public class Planilha extends javax.swing.JFrame {
    
    private String[][] dados = new String[100][3];
    private int total = 0;
    private String[] colunas = {"Uso", "Quantidade", "Data"};
    
    private JTextField campoUso = new JTextField(18);
    private JTextField campoQuantidade = new JTextField(8);
    private JTextField campoData = new JTextField(10);
    
    private DefaultTableModel modeloTabela;
    private JTable tabela;
    
    private JLabel labelStatus;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Planilha.class.getName());

   
    public Planilha() {
        initComponents();
         JLabel texto = new JLabel("Você está na Tela 2");

        add(texto);

        setLocationRelativeTo(null);
        
        setTitle("Contagem de folhas");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setBackground(new Color (0, 185, 189));
        
        setTitle("Contagem de folhas");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 

        
        JPanel principal = new JPanel(new BorderLayout(8, 8));
        principal.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

       
        principal.add(criarFormulario(), BorderLayout.NORTH);
        principal.add(criarTabela(),    BorderLayout.CENTER);
        principal.add(criarRodape(),    BorderLayout.SOUTH);

        setContentPane(principal);
        setVisible(true);
        getContentPane().setBackground(new Color(56, 109, 189));
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        carregarCSV(); 
    }
     private JPanel criarFormulario() {
         
         JPanel Planilha = new JPanel(new BorderLayout(8, 8));
        Planilha.setBackground(new Color(0, 185, 189));

        Planilha.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createTitledBorder("Novo Registro"));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 6, 5, 6);
        p.setBackground(new Color(255, 255, 253));

        
        g.gridy = 0; g.fill = GridBagConstraints.NONE;
        g.gridx = 0; p.add(new JLabel("Uso:"), g);
        g.gridx = 2; p.add(new JLabel("Quantidade:"), g);
        g.gridx = 4; p.add(new JLabel("Data:"), g);

        
        g.gridy = 1; g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1;
        g.gridx = 0; p.add(campoUso, g);
        g.gridx = 2; p.add(campoQuantidade, g);
        g.gridx = 4; p.add(campoData, g);

        
        g.weightx = 0; g.fill = GridBagConstraints.NONE;
        JButton btnAdd = new JButton("Adicionar");
        btnAdd.setBackground(new Color(0, 185, 189));
        JButton btnClr = new JButton("Limpar");
        btnClr.setBackground(new Color(0, 185, 189));

        btnAdd.addActionListener(e -> adicionar());
        btnClr.addActionListener(e -> limpar());
        campoData.addActionListener(e -> adicionar());

        g.gridx = 6; p.add(btnAdd, g);
        g.gridx = 7; p.add(btnClr, g);
        return p;
        
    }
     
     private JPanel criarTabela() {
        JPanel p = new JPanel(new BorderLayout(0, 6));
        p.setBorder(BorderFactory.createTitledBorder("Registros"));
        p.setBackground(new Color(255, 255, 253));

        
        modeloTabela = new DefaultTableModel(colunas, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };


        tabela = new JTable(modeloTabela);
        tabela.setRowHeight(24);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        
        JButton btnRemover = new JButton("Remover linha selecionada");
        btnRemover.addActionListener(e -> remover());
        btnRemover.setBackground(new Color(0, 185, 189));

        p.add(new JScrollPane(tabela), BorderLayout.CENTER);
        p.add(btnRemover, BorderLayout.SOUTH);
        return p;
        
    }
     
     private JPanel criarRodape() {
        JPanel p = new JPanel(new BorderLayout(8, 0));
        labelStatus = new JLabel("Pronto.");

        JButton btnExportar = new JButton("Exportar para CSV");
        btnExportar.addActionListener(e -> exportar());
        setBackground(new Color (0, 185, 189));
        btnExportar.setBackground(new Color(0, 185, 189));

        p.add(labelStatus,  BorderLayout.WEST);
        p.add(btnExportar,  BorderLayout.EAST);
        return p;
    }
     
     private void adicionar() {
        String Uso  = campoUso.getText().trim();
        String qtd      = campoQuantidade.getText().trim();
        String data    = campoData.getText().trim();

        
        if (Uso.isEmpty() || qtd.isEmpty() || data.isEmpty()) {
            labelStatus.setText("Preencha todos os campos.");
            return;
        }

        
        try { Integer.parseInt(qtd); }
        catch (NumberFormatException e) {
            labelStatus.setText("Quantidade deve ser número inteiro.");
            return;
        }

        if (total >= dados.length) {
            labelStatus.setText("Limite de " + dados.length + " registros atingido.");
            return;
        }

        dados[total][0] = Uso;
        dados[total][1] = qtd;
        dados[total][2] = data;
        total++;

        
        modeloTabela.addRow(new Object[]{Uso, qtd, data});

        labelStatus.setText(total + " registro(s) na lista.");
        limpar();
        campoUso.requestFocus();
        modeloTabela.addRow(new Object[]{Uso, qtd, data});
        salvarCSVAutomatico(); 
    }
     
     private void remover() {
        int linha = tabela.getSelectedRow();
        if (linha < 0) {
            labelStatus.setText("Selecione uma linha para remover.");
            return;
        }

        for (int i = linha; i < total - 1; i++) {
            dados[i][0] = dados[i + 1][0];
            dados[i][1] = dados[i + 1][1];
            dados[i][2] = dados[i + 1][2];
        }
        dados[total - 1][0] = null;
        dados[total - 1][1] = null;
        dados[total - 1][2] = null;
        total--;

        modeloTabela.removeRow(linha);
        labelStatus.setText(total + " registro(s) na lista.");
    }
     
     private void limpar() {
        campoUso.setText("");
        campoQuantidade.setText("");
        campoData.setText("");
    }
     
     private void exportar() {
        if (total == 0) {
        labelStatus.setText("Adicione registros antes de exportar.");
        return;
    }

    JFileChooser fc = new JFileChooser();
    fc.setSelectedFile(new java.io.File("planilha.csv"));
    if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

    String caminho = fc.getSelectedFile().getAbsolutePath();
    if (!caminho.endsWith(".csv")) caminho += ".csv";

    try (java.io.BufferedWriter bw = new java.io.BufferedWriter(
            new java.io.FileWriter(caminho))) {

        bw.write("Uso;Quantidade;Data");
        bw.newLine();

        for (int i = 0; i < total; i++) {
            bw.write(dados[i][0] + ";" + dados[i][1] + ";" + dados[i][2]);
            bw.newLine();
        }

        labelStatus.setText("Exportado: " + caminho);
        JOptionPane.showMessageDialog(this, "Arquivo salvo em:\n" + caminho);

    } catch (java.io.IOException e) {
        labelStatus.setText("Erro ao salvar: " + e.getMessage());
        JOptionPane.showMessageDialog(this, "Erro: " + e.getMessage(),
                "Erro", JOptionPane.ERROR_MESSAGE);
    }
    }
     private void salvarCSVAutomatico() {
    String caminho = "registros.csv";
    try (java.io.BufferedWriter bw = new java.io.BufferedWriter(
            new java.io.FileWriter(caminho))) {

        bw.write("Uso;Quantidade;Data");
        bw.newLine();
        for (int i = 0; i < total; i++) {
            bw.write(dados[i][0] + ";" + dados[i][1] + ";" + dados[i][2]);
            bw.newLine();
        }
    } catch (java.io.IOException e) {
        labelStatus.setText("Erro ao salvar automaticamente.");
    }
}
     
     private void carregarCSV() {
    java.io.File arquivo = new java.io.File("registros.csv");
    if (!arquivo.exists()) return;

    try (java.io.BufferedReader br = new java.io.BufferedReader(
            new java.io.FileReader(arquivo))) {

        br.readLine();
        String linha;
        while ((linha = br.readLine()) != null && total < dados.length) {
            String[] partes = linha.split(";");
            if (partes.length == 3) {
                dados[total][0] = partes[0];
                dados[total][1] = partes[1];
                dados[total][2] = partes[2];
                modeloTabela.addRow(new Object[]{partes[0], partes[1], partes[2]});
                total++;
            }
        }
        labelStatus.setText(total + " registro(s) carregado(s).");
    } catch (java.io.IOException e) {
        labelStatus.setText("Erro ao carregar CSV.");
    }
}
     
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();

        jTextField2.setText("jTextField2");

        jTextField3.setText("jTextField3");

        jTextField1.setText("jTextField1");
        jTextField1.addActionListener(this::jTextField1ActionPerformed);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Uso", "Quantidade", "Data"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jTextField4.setText("jTextField4");

        jTextField5.setText("jTextField5");

        jTextField6.setText("jTextField6");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 387, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 661, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 909, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> {
        new Planilha().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    // End of variables declaration//GEN-END:variables
}
