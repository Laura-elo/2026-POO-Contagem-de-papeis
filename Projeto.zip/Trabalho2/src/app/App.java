
package app;

import view.Inicio;


public class App {


    public static void main(String[] args) {
        Inicio i = new Inicio();
        i.setVisible(true);
    }
    
}
